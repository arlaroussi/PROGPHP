<?php

$marque = array("volvo","BMW","Toyota");

for ($i=0; $i<count($marque); $i=++;)
{
	echo "Achat de : " . $marque[$i] . "<br/>";
}

?>